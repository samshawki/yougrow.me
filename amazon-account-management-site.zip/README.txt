# Amazon Account Management — Static Website

Use these files with GitHub Pages.

## Deploy
1) Create a new GitHub repo and upload all files.
2) Repo → Settings → Pages → Deploy from a branch → main + /(root).
3) Your site will appear at https://<username>.github.io/<repo>.

## Custom domain (GoDaddy)
- CNAME: www → <username>.github.io
- A records (@): 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153
- In GitHub Pages set custom domain to www.yougrow.me and enable HTTPS.
